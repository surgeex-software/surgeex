// small helper: format numbers (K/M)
function fmt(n){
  if(n>=1e9) return (n/1e9).toFixed(1)+'B';
  if(n>=1e6) return (n/1e6).toFixed(2)+'M';
  if(n>=1e3) return (n/1e3).toFixed(1)+'K';
  return String(n);
}

/* Simulated live metrics — simple and lightweight */
const BASE = { launches:1230000, nodes:8740000, installs:41270000 };
let state = Object.assign({}, BASE);

function randomStep(val){
  const mag = Math.max(5, Math.round(Math.abs(val)* (0.00025 + Math.random()*0.0008) ));
  const dir = Math.random()>0.5?1:-1;
  return Math.max(0, val + Math.round(dir * mag));
}

function updateMetrics(){
  state.launches = randomStep(state.launches);
  state.nodes = randomStep(state.nodes);
  state.installs = randomStep(state.installs);

  document.querySelector('[data-key="launches"]').textContent = fmt(state.launches);
  document.querySelector('[data-key="nodes"]').textContent = fmt(state.nodes);
  document.querySelector('[data-key="installs"]').textContent = fmt(state.installs);
}

setInterval(updateMetrics, 1400);
updateMetrics();

/* marquee duplication for continuous scroll */
(function prepareMarquee(){
  const track = document.querySelector('.marquee-track');
  if(!track) return;
  // duplicate contents to create smooth loop
  const clone = track.innerHTML;
  track.innerHTML += clone + clone;
})();

/* waitlist form: simple client-side confirm (no server) */
const f = document.getElementById('waitlist');
if(f) f.addEventListener('submit', function(e){
  e.preventDefault();
  const email = f.email.value.trim();
  if(!email || !email.includes('@')){
    alert('Please enter a valid email');
    return;
  }
  f.reset();
  alert('Thanks — we saved your email (demo). You will be notified when we launch!');
});

/* small helpers */
document.getElementById('year').textContent = new Date().getFullYear();