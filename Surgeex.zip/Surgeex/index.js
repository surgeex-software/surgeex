import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'

/* Inline small SVG logos for marquee (replace later with /public svgs) */
const LogoGlyph = ({ id, color = '#fff' }) => {
  const glyphs = {
    Quantara: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><circle cx="18" cy="20" r="14" fill="none" stroke="'+color+'" stroke-width="6"/></svg>',
    Nexora: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><rect x="12" y="6" width="26" height="28" rx="6" fill="none" stroke="'+color+'" stroke-width="6"/></svg>',
    Cryenix: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><path d="M12 30 L30 6 L54 30" fill="none" stroke="'+color+'" stroke-width="6" stroke-linecap="round"/></svg>',
    Zyphor: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><path d="M10 20 Q26 6 42 20 T74 20" fill="none" stroke="'+color+'" stroke-width="6"/></svg>',
    Axionics: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><path d="M10 10 H40 V30 H10 Z" fill="none" stroke="'+color+'" stroke-width="6"/></svg>',
    Vortix: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><path d="M10 20 C24 6 40 30 70 20" fill="none" stroke="'+color+'" stroke-width="6"/></svg>',
    Helion: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="20" r="12" fill="none" stroke="'+color+'" stroke-width="6"/></svg>',
    Aurevox: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><path d="M10 30 L30 10 L50 30" fill="none" stroke="'+color+'" stroke-width="6"/></svg>',
    Cyvex: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><path d="M20 10 H60 M20 30 H60" fill="none" stroke="'+color+'" stroke-width="6"/></svg>',
    Novatek: '<svg viewBox="0 0 100 40" xmlns="http://www.w3.org/2000/svg"><path d="M10 20 H90" fill="none" stroke="'+color+'" stroke-width="6"/></svg>'
  }
  return <div dangerouslySetInnerHTML={{__html: glyphs[id] || glyphs['Quantara']}} />
}

const partnerRows = [
  ['Quantara','Nexora','Cryenix','Zyphor','Axionics'],
  ['Vortix','Helion','Aurevox','Cyvex','Novatek']
]

export default function Home(){
  // base realistic numbers
  const base = {
    Launches: 1230000,
    Nodes: 8740000,
    Models: 362000,
    Installs: 41270000,
    Patches: 1980000,
    ReqSec: 240000
  }

  const [metrics, setMetrics] = useState({...base})

  useEffect(()=>{
    const iv = setInterval(()=>{
      setMetrics(prev=>{
        const change = (v) => {
          const mag = Math.max(10, Math.round(Math.abs(v) * (0.0004 + Math.random()*0.001)));
          const dir = Math.random() > 0.5 ? 1 : -1;
          return Math.max(0, v + Math.round(dir * Math.min(mag, Math.max(5, Math.round(mag/2)))))
        }
        return {
          Launches: change(prev.Launches),
          Nodes: change(prev.Nodes),
          Models: change(prev.Models),
          Installs: change(prev.Installs),
          Patches: change(prev.Patches),
          ReqSec: change(prev.ReqSec)
        }
      })
    }, 1600)
    return ()=> clearInterval(iv)
  },[])

  const fmt = (n) => {
    if(n >= 1_000_000_000) return (n/1_000_000_000).toFixed(1)+'B'
    if(n >= 1_000_000) return (n/1_000_000).toFixed(2)+'M'
    if(n >= 1_000) return (n/1_000).toFixed(1)+'K'
    return String(n)
  }

  return (
    <div>
      <header className="hero" style={{background:'linear-gradient(180deg,#050505 0%, #050a0a 100%)'}}>
        <div className="container" style={{display:'flex', alignItems:'center', gap:24}}>
          <div style={{flex:1}}>
            <div style={{display:'flex', alignItems:'center', gap:12}}>
              <div style={{width:56, height:56, borderRadius:14, background:'#00f07a', display:'flex', alignItems:'center', justifyContent:'center', color:'#030303', fontWeight:800}}>✶</div>
              <div style={{fontSize:18, fontWeight:700}}>Surgeex</div>
            </div>

            <h1 className="h1" style={{marginTop:18}}>Building the future of software — fast, elegant, trusted.</h1>

            <p className="lead">We craft intelligent tools and launch-ready platforms that help creators and startups ship products with confidence. Free for early creators.</p>

            <div style={{marginTop:18, display:'flex', gap:12}}>
              <a className="btn">Explore Products</a>
              <a className="btn ghost">About Surgeex</a>
            </div>
          </div>

          <div style={{width:340, borderRadius:14, padding:18, background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', border:'1px solid rgba(255,255,255,0.03)'}}>
            <h3 style={{margin:0,fontSize:16,fontWeight:700}}>Join waitlist</h3>
            <p style={{marginTop:8,color:'#bbb'}}>Free for early creators — get notified when we launch new tools.</p>
            <div style={{marginTop:12, display:'flex', gap:8}}>
              <input placeholder="Email address" style={{flex:1,padding:10,borderRadius:8,border:'none',background:'#0b0b0c',color:'#fff'}}/>
              <button className="btn" style={{padding:'10px 12px'}}>Join</button>
            </div>
          </div>
        </div>
      </header>

      <main className="container" style={{paddingBottom:40}}>
        <section style={{marginTop:6}}>
          <h2 style={{fontWeight:700,fontSize:20}}>Latest Updates</h2>
          <div className="card-grid" style={{marginTop:16}}>
            {Array.from({length:4}).map((_,i)=>(
              <div className="card" key={i}>
                <div style={{height:120, borderRadius:8, background:'linear-gradient(90deg,#0b0b0c,#0d0d0d)'}}></div>
                <h4 style={{marginTop:12, marginBottom:6}}>Update title {i+1}</h4>
                <p style={{color:'#9a9a9a', fontSize:13, margin:0}}>Short description to tease the feature and invite users to read more.</p>
              </div>
            ))}
          </div>

          <div style={{textAlign:'center', marginTop:18}}>
            <button className="btn ghost">View More</button>
          </div>
        </section>

        <section style={{marginTop:42}}>
          <h3 style={{fontWeight:700}}>Global impact — live</h3>
          <p style={{color:'#9a9a9a', marginTop:6}}>Real-time activity across our platform (simulated for demo).</p>

          <div className="metrics">
            <MetricBox number={fmt(metrics.Launches)} label="Launches" />
            <MetricBox number={fmt(metrics.Nodes)} label="Active Nodes" />
            <MetricBox number={fmt(metrics.Models)} label="AI Models" />
            <MetricBox number={fmt(metrics.Installs)} label="App Installs" />
            <MetricBox number={fmt(metrics.Patches)} label="Security Patches" />
            <MetricBox number={fmt(metrics.ReqSec)} label="Req / sec" />
          </div>
        </section>

        <section style={{marginTop:28}}>
          <div className="marquee" aria-hidden>
            <Marquee row={partnerRows[0]} duration={22000} direction="left" />
            <Marquee row={partnerRows[1]} duration={26000} direction="right" />
          </div>
        </section>

        <section style={{marginTop:36, textAlign:'center', padding:40, background:'linear-gradient(90deg, rgba(0,240,122,0.03), rgba(0,200,170,0.02))', borderRadius:12}}>
          <h3 style={{margin:0, fontSize:22}}>Let's bring your vision to life</h3>
          <p style={{color:'#bdbdbd', marginTop:8}}>We build, launch, and maintain software products designed for creators and businesses.</p>
          <div style={{marginTop:16}}><a className="btn">Get Started</a></div>
        </section>

      </main>

      <footer style={{padding:'36px 0'}}>
        <div className="container" style={{display:'flex', justifyContent:'space-between', alignItems:'center', gap:18}}>
          <div>
            <div style={{fontWeight:700}}>Surgeex</div>
            <div style={{color:'#919191', marginTop:8}}>© {new Date().getFullYear()} Surgeex — All rights reserved</div>
          </div>
          <div style={{color:'#9a9a9a'}}>Follow us (placeholders)</div>
        </div>
      </footer>
    </div>
  )
}

/* Sub components */

function MetricBox({ number, label }){
  const up = Math.random() > 0.35
  return (
    <motion.div className="metric" initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} transition={{duration:0.45}}>
      <div style={{display:'flex', alignItems:'baseline', gap:8}}>
        <div className="num" style={{fontSize:28}}>{number}</div>
        <div style={{color: up ? '#5efc95' : '#ff8b8b', fontWeight:700}}>{up ? '↑' : '↓'}</div>
      </div>
      <div className="label">{label}</div>
    </motion.div>
  )
}

function Marquee({ row = [], duration = 20000, direction = 'left' }){
  const items = [...row, ...row, ...row]
  const animStyle = {
    display:'inline-flex',
    gap:22,
    alignItems:'center',
    animation: `${direction}-scroll ${duration}ms linear infinite`
  }

  return (
    <div style={{overflow:'hidden', padding:'8px 0', marginBottom:8}}>
      <style>{`
        @keyframes left-scroll {
          0% { transform: translateX(0) }
          100% { transform: translateX(-33.333%) }
        }
        @keyframes right-scroll {
          0% { transform: translateX(0) }
          100% { transform: translateX(33.333%) }
        }
      `}</style>

      <div style={animStyle}>
        {items.map((id, idx)=>(
          <div key={id+'-'+idx} className="logo" title={id} style={{width:110, height:46, display:'flex', alignItems:'center', justifyContent:'center'}}>
            <LogoGlyph id={id} color="#fff"/>
          </div>
        ))}
      </div>
    </div>
  )
}