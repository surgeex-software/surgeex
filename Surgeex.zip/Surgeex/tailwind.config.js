module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        surge: {
          50: '#eafff4',
          100: '#b8ffdf',
          300: '#2fffb0',
          500: '#00f07a'
        },
        softblack: '#070607'
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui']
      }
    }
  },
  plugins: []
}